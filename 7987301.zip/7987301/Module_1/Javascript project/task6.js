let events = [
    { name: "Music Fest", category: "Music" },
    { name: "Tech Talk", category: "Technology" }
];

// push()
events.push({ name: "Dance Show", category: "Music" });

// filter()
let musicEvents = events.filter(event =>
    event.category === "Music"
);

// map()
let cards = musicEvents.map(event =>
    `<p>Event: ${event.name}</p>`
);

document.getElementById("output").innerHTML =
cards.join("");