let output = "";

// addEvent()
function addEvent(name) {
    output += `<p>Event Added: ${name}</p>`;
}

// registerUser()
function registerUser(user) {
    output += `<p>User Registered: ${user}</p>`;
}

// filterEventsByCategory()
function filterEventsByCategory(events, callback) {
    return events.filter(callback);
}

// Closure
function registrationCounter() {
    let count = 0;

    return function () {
        count++;
        return count;
    };
}

const totalRegistrations = registrationCounter();

addEvent("Music Fest");
registerUser("Priya");

output += `<p>Total Registrations: ${totalRegistrations()}</p>`;
output += `<p>Total Registrations: ${totalRegistrations()}</p>`;

// Higher-Order Function
const events = [
    { name: "Music Fest", category: "Music" },
    { name: "Tech Talk", category: "Technology" }
];

const result = filterEventsByCategory(
    events,
    event => event.category === "Music"
);

result.forEach(event => {
    output += `<p>Filtered Event: ${event.name}</p>`;
});

document.getElementById("output").innerHTML = output;