// Register button
function registerEvent() {
    document.getElementById("result").innerHTML =
        "Registration Successful!";
}

// onchange event
document.getElementById("category").onchange = function () {
    alert("Selected Category: " + this.value);
};

// keydown event
document.getElementById("search").addEventListener("keydown", function () {
    console.log("Searching: " + this.value);
});